export default {
  TEXT_DATA_API: 'http://www.randomtext.me/api/',
};
