const actions = {
  SET_TEXT_DATA: 'SET_TEXT_DATA',
};

export default actions;
