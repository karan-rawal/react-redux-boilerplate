# react-redux-boilerplate
The react redux boilerplate code. With unit testing and sass support.
